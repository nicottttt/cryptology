void implementation_check(const char *fctname, int n);
