#ifndef __FRS__RANDOM

/*! \file random.h
 */

unsigned int random_seed();

#define __FRS__RANDOM
#endif
