int CRT2(mpz_t n, mpz_t r0, mpz_t m0, mpz_t r1, mpz_t m1);
int CRT(mpz_t n, mpz_t *r, mpz_t *m, int nb_pairs);

